# DBM-Mods

Here you can find some Modifications for Discord Bot Maker!
Feel free to use them in your bots. But, if you want to share this files, please, share the URL of this GitHub page, so that everyone can have everything up to date!

Make sure to join the [DBM Network server](https://discord.gg/3QxkZPK
) to stay updated and be able to suggest stuff! More information at: https://dbm-network.org/

## How to install the Modifications:
1. Download this file: http://bit.ly/2pJiqv6
2. Open ZIP and open the first (and only) folder
3. Open your Steam Library and open the Softwares tab
4. Choose Discord Bot Maker &rarr; Local Files &rarr; Browse Local Files
5. Now copy the files you downloaded out of the zip file into that folder you just opened (*Please overwrite existing ones*)

And that's it

If you don't run your bot with DBM make sure to copy this actions to your bot's directory too! Same for hosted bots! If you don't do this, missing actions will appear as **"XYZ is not an Action"** in your console.

If you have any more questions: [Join our Discord](https://discord.gg/3QxkZPK) or make a ticket on the [Support Website](https://dbm-support.site/index.php?a=add&category=5).
